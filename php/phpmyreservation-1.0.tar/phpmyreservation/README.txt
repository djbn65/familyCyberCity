Check out the wiki for installation instructions & documentation:

http://code.google.com/p/phpmyreservation/w/list
